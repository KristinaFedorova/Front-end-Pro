
function getData() {
    let xhr = new XMLHttpRequest()
    xhr.open('GET', 'http://api.openweathermap.org/data/2.5/weather?q=LVIV&units=metric&APPID=5d066958a60d315387d9492393935c19')
    xhr.send();
    xhr.onload = () => {
        if (xhr.status === 200) {
            let response = xhr.response
            response = JSON.parse(response)

            console.log(response)
            for (let i = 0; i < 9; i++) {
                let temp = document.getElementById(a[i])
                temp.innerHTML = JSON.parse(response).main.temp
                if (a[i] === 'pressure') {
                    temp.innerHTML = JSON.parse(response).main.pressure
                } else if (a[i] === 'description') {
                    let description = response.weather.description
                    temp.innerHTML = JSON.parse(description)
                } else if (a[i] === 'humidity') {
                    temp.innerHTML = JSON.parse(response).main.humidity
                } else if (a[i] === 'speed') {
                    temp.innerHTML = JSON.parse(response).wind.speed
                } else if (a[i] === 'deg') {
                    temp.innerHTML = JSON.parse(response).wind.deg
                } else if (a[i] === 'icon') {
                    temp.innerHTML = JSON.parse(response).weather.icon
                }
                console.log(temp)
            }
        }
        if (xhr.status === 500) {
            console.log('error')
        }
    }
}

let a = ['temp', 'pressure', 'description', 'humidity', "speed", "deg", "icon"]
getData(a)


let today = new Date();
document.getElementById('time').innerHTML=today;





